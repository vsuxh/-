#Dire guy looking this source code:Pillowというライブラリを使用しています->pip install Pillow  で端末にインスコしてね
from PIL import Image


ASCII_CHARS = '@%#*+=-:. '

def scale_image(image, new_width=100):
    #画像をリサイズする
    (original_width, original_height) = image.size
    aspect_ratio = original_height / float(original_width)
    new_height = int(aspect_ratio * new_width * 0.55) # 縦横比を調整
    new_image = image.resize((new_width, new_height))
    return new_image

def convert_to_grayscale(image):
    #グレースケールに変換
    return image.convert('L')

def map_pixels_to_ascii(image):
    #ピクセルをASCII文字にマッピン
    pixels = image.getdata()
    ascii_str = ''
    for pixel_value in pixels:
        # 明るさ(0-255)を文字リストのインデックスに変換
        index = int(pixel_value / 255 * (len(ASCII_CHARS) - 1))
        ascii_str += ASCII_CHARS[index]
    return ascii_str

def main(image_path):
    try:
        image = Image.open(image_path)
    except Exception as e:
        print(e)
        return

    # 1. リサイズ
    image = scale_image(image)
    
    # 2. グレースケール化
    grayscale_image = convert_to_grayscale(image)
    
    # 3. ピクセルを文字に変換
    ascii_str = map_pixels_to_ascii(grayscale_image)
    
    # 4. AAを出力
    img_width = grayscale_image.width
    for i in range(0, len(ascii_str), img_width):
        print(ascii_str[i:i+img_width])

# ここに変換したい画像のパスを入れる
main(r'C:\Users\gaoda\puroken\sakuhin4\kosensai\social credit.png')
